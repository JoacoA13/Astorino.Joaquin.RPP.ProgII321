
package parcial1;


public class YaExisteLaNaveException extends RuntimeException{
    private static final String mensaje = "Ya existe esa nave";

    public YaExisteLaNaveException() {
        super(mensaje);
    }    
}
