
package parcial1;

public class CruceroEstelar extends Nave{
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidad, int anioLanzamiento) {
        super(nombre, capacidad, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return "Crucero Estelar{" + "nombre='" + super.getNombre() + '\'' + ", capacidad=" + super.getCapacidad() + ", anioLanzamiento=" + super.getAnioLanzamiento() + ", cantidadPasajeros=" + cantidadPasajeros +'}';
    }
    
    
    
}
