package parcial1;

public class TestNaves {

    public static void main(String[] args) {
        EstacionEspacial est = new EstacionEspacial();
        Carguero car1 = new Carguero(123,"Carguerin", 2100,1920);
        
        try {
            est.agregarNave(new Carguero(600,"aSD", 2100,1920));
            est.agregarNave(new CruceroEstelar(200, "Galaxy", 1200, 1892));
            est.agregarNave(new NaveExploracion(TipoMision.CARTOGRAFIA, "Explorer", 2, 4500));
            est.agregarNave(car1);
        
        } catch (NullPointerException | YaExisteLaNaveException | IllegalArgumentException | CargaInvalidaException e) {
            System.out.println(e.getMessage());
        }
        
        car1.explorar();
        est.mostrarNaves();
    }
    
}
