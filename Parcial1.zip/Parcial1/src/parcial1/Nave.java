package parcial1;

import java.util.ArrayList;
import java.util.Objects;

public abstract class Nave {
    private String nombre;
    private int capacidad;
    private int anioLanzamiento;

    public Nave(String nombre, int capacidad, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }
    
    @Override
    public boolean equals(Object o
    ) {if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Nave other = (Nave) o;
        
        return other.nombre.equals(nombre);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
}
