


package parcial1;


public class CargaInvalidaException extends RuntimeException {
    private static final String MENSAJE = "La carga debe estar entre %s y %s. Carga proporcionada: %s.";

    public CargaInvalidaException(double minCarga, double maxCarga, double cargaProporcionada) {
        super(String.format(MENSAJE, minCarga, maxCarga, cargaProporcionada));
    }
}
