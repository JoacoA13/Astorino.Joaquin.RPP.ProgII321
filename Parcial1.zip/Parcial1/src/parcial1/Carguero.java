package parcial1;


public class Carguero extends Nave implements Explorar{
    private static final double MIN_CARGA = 100;
    private static final double MAX_CARGA = 500;
    private double carga;

    public Carguero(double carga, String nombre, int capacidad, int anioLanzamiento) {
        super(nombre, capacidad, anioLanzamiento);
        if (carga < MIN_CARGA || carga > MAX_CARGA) {
            throw new CargaInvalidaException(MIN_CARGA, MAX_CARGA, carga);
        }
        this.carga = carga;
    }
    
    @Override
    public String toString() {
        return "Carguero{" + "nombre='" + super.getNombre() + '\'' + ", capacidad=" + super.getCapacidad() + ", anioLanzamiento=" + super.getAnioLanzamiento() + ", carga=" + carga +'}';
    }

    
    @Override
    public void explorar() {
        System.out.println("Nave de carga: " + this.getNombre() + ", salio a explorar");
    }
}
