package parcial1;

public class NaveExploracion extends Nave implements Explorar{
    private TipoMision tipo;

    public NaveExploracion(TipoMision tipo, String nombre, int capacidad, int anioLanzamiento) {
        super(nombre, capacidad, anioLanzamiento);
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Exploradora{" + "nombre='" + super.getNombre() + '\'' + ", capacidad=" + super.getCapacidad() + ", anioLanzamiento=" + super.getAnioLanzamiento() + ", tipo=" + tipo +'}';
    }

    @Override
    public void explorar() {
        System.out.println("Nave de exploracion: " + this.getNombre() + ", salio a explorar");
    }
    
    
   
}
