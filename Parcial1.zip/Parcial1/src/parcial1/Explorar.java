package parcial1;

public interface Explorar {
    void explorar();
}
