package parcial1;

import java.util.ArrayList;

class EstacionEspacial {
    private ArrayList<Nave> naves;

    public EstacionEspacial() {
        this.naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave nave){
        if (nave == null) {
            throw new NullPointerException("No se puede agregar un nulo.");
        }
        if (!yaExiste(nave)) {
            naves.add(nave);
        }
    }
    
    private boolean yaExiste(Nave nave){
        if(naves.contains(nave)){
            throw new YaExisteLaNaveException();
        }
        return false;
    }
    
    public void mostrarNaves(){
        for (Nave n: naves) {
            System.out.println(n);
        }
    }
}
