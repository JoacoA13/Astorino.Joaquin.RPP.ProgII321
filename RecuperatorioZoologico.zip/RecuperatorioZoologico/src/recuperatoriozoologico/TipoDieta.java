
package recuperatoriozoologico;

public enum TipoDieta {
    HERBIVORO,
    CARNIVORO,
    OMNIVORO;
}
