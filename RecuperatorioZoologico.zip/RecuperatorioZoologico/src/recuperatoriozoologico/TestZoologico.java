package recuperatoriozoologico;

public class TestZoologico {

    public static void main(String[] args) {
        CentroAnimales zoologico = new CentroAnimales();
        
        try {
            //Descomentar para testeo
            /*
            //Dupliado:
            zoologico.agregarAnimal(new Reptil("queratinosa", "ectotermia", "Carlos", 2));
            //Vacio:
            zoologico.agregarAnimal(null);
            */
            zoologico.agregarAnimal(new Reptil("queratinosa", "ectotermia", "Carlos", 2));
            zoologico.agregarAnimal(new Mamifero(12.5, TipoDieta.CARNIVORO, "Pepe", 10));
            zoologico.agregarAnimal(new Ave(54.7, "Tito", 20));
        } catch (NullPointerException | YaExisteException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
        }
        System.out.println("");
        System.out.println("---------ANIMALES---------");
        zoologico.mostrarAnimales();
        System.out.println("---------------------------");
        
        System.out.println("");
        System.out.println("---------VACUNACION---------");
        zoologico.vacunarAnimales();
        System.out.println("----------------------------");
    }
}
