package recuperatoriozoologico;


public class YaExisteException extends RuntimeException{
    private static final String MESSAGE = "El animal ya existe";
        public YaExisteException(){
            super(MESSAGE);
        }
}
