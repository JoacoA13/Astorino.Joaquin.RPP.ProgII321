package recuperatoriozoologico;

public interface Vacunacion {
    void vacunar();
}
