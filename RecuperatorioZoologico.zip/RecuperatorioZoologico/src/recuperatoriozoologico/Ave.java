package recuperatoriozoologico;


public class Ave extends Animal implements Vacunacion{
    private double envergaduraAlas;

    public Ave(double envergadura, String nombre, int edad) {
        super(nombre, edad);
        this.envergaduraAlas = envergadura;
    }
    
    @Override
    public void vacunar() {
        System.out.println("Ave " + getNombre() + ", Vacunada");
    }

    @Override
    public String toString() {
        return "Ave{" + "envergaduraAlas=" + envergaduraAlas;
    }
    
    
}
