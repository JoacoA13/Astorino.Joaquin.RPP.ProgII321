package recuperatoriozoologico;

import java.util.ArrayList;

class CentroAnimales {
    private ArrayList<Animal> animales;
    
    public CentroAnimales() {
        this.animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal){
        if(animal == null){
            throw new NullPointerException("No se puede agregar algo vacio");
        }
        if(!yaExiste(animal)){
            animales.add(animal);
            System.out.println("Informacion Animal: " + animal.getNombre() + " agregado correctamente al zoologico");
        }
    }
    
    private boolean yaExiste(Animal animal){
        if(animales.contains(animal)){
            throw new YaExisteException();
        }
        return false;
    }
    
    public void mostrarAnimales(){
        for(Animal animal: animales){
            System.out.println(animal);
        }
    }
    
    public void vacunarAnimales(){
      for(Animal animal : animales){
          if(animal instanceof Vacunacion vacuna){
              vacuna.vacunar();
          }
          else{
              System.out.println("No se puede vacunar al animal: " + animal.getNombre());
          }
        }  
    }
}
